// ── Macro-stage definitions ──────────────────────────────────────────

export const MACRO_STAGES = [
  {
    id: 'shape',
    name: 'Shape',
    phaseRange: [0, 7],
    phases: ['Triage','ItemSelect','Setup','Context','Shape','Critique','Gate','Scope'],
  },
  {
    id: 'build',
    name: 'Build',
    phaseRange: [8, 13],
    phases: ['Interface','Int.Gate','Selection','Planning','Plan.Gate','Execution'],
  },
  {
    id: 'verify',
    name: 'Verify',
    phaseRange: [14, 16],
    phases: ['Verification','Diff.Gate','Audit'],
  },
];

export const PHASE_NAMES = [
  'Triage','ItemSelect','Setup','Context','Shape','Critique','Gate','Scope',
  'Interface','Int.Gate','Selection','Planning','Plan.Gate','Execution',
  'Verification','Diff.Gate','Audit',
];

// ── Data fetching ────────────────────────────────────────────────────

/**
 * Try to read stelow.json from the active worktree.
 * Returns null if the file doesn't exist or can't be parsed.
 */
export async function loadTrackingData() {
  try {
    const res = await muxy.files.read('stelow.json');
    if (!res || !res.content) return null;
    const tracking = JSON.parse(res.content);
    const projectPath = await getActiveWorkspacePath().catch(() => null);
    return normalizeTrackingDataForProject(tracking, projectPath);
  } catch {
    return null;
  }
}

/**
 * Try to read inbox items from .stelow/inbox/items.md.
 * Returns an array of item strings (empty array if none).
 */
export async function loadInbox() {
  try {
    const res = await muxy.files.read('.stelow/inbox/items.md');
    if (!res || !res.content) return [];
    return res.content
      .split('\n')
      .map(l => l.trim())
      .filter(l => l.length > 0 && !l.startsWith('#'));
  } catch {
    return [];
  }
}

/**
 * Write inbox items back to .stelow/inbox/items.md.
 */
export async function saveInbox(items) {
  const header = '# Inbox\n\n';
  const body = items.length > 0 ? items.join('\n') + '\n' : '\n';
  await muxy.files.write('.stelow/inbox/items.md', header + body);
}

/**
 * Try to load the project name for display.
 * Returns null if none found.
 * Also returns the project name (dir name) for display.
 */
export async function loadProjectName() {
  // Try package.json first (Node/npm projects)
  try {
    const res = await muxy.files.read('package.json');
    if (res && res.content) {
      const pkg = JSON.parse(res.content);
      return pkg.name || pkg.displayName || null;
    }
  } catch { /* ignore */ }
  // Try go.mod (Go projects)
  try {
    const res = await muxy.files.read('go.mod');
    if (res && res.content) {
      const match = res.content.match(/^module\s+(.+)$/m);
      if (match) return match[1].trim();
    }
  } catch { /* ignore */ }
  // Fallback: workspace directory name
  try {
    const projects = await muxy.projects.list();
    const active = projects.find(p => p.isActive);
    if (active?.path) {
      return active.path.split('/').filter(Boolean).pop() || null;
    }
  } catch { /* ignore */ }
  return null;
}

function isHiddenWorkflowStatus(status) {
  return ['archived', 'aborted', 'stopped', 'cancelled', 'canceled'].includes(status);
}

/**
 * Flatten all `wf.scopes` across all workflows in a tracking file into
 * a uniform list of `{ workflow, scope, project }` entries. Used by the
 * cross-workflow "Scope view" tab in the Muxy panel.
 *
 * Each card shows: project path (worktree-aware), workflow name + status,
 * scope id + name, scope progress. Filter strip on top narrows the list.
 *
 * **Sandboxing caveat:** Muxy's `muxy.files.read` is sandboxed to the
 * active worktree. This view therefore reads scopes from the active
 * workspace's `stelow.json` only. For multi-worktree scope aggregation,
 * switch worktrees manually; cross-project aggregation would require
 * Muxy to expose a `projects.read.files` API (not yet available —
 * see https://muxy.app/docs/extensions/files).
 *
 * Within the active worktree, multiple workflows in the same stelow.json
 * ARE visible (the panel already supports this for workflow cards; this
 * function reuses the same data source).
 */
export function flattenScopesForView(tracking) {
  if (!tracking?.workflows) return [];
  const out = [];
  for (const wf of tracking.workflows) {
    if (!Array.isArray(wf.scopes)) continue;
    for (const scope of wf.scopes) {
      out.push({
        project: wf.cwd ?? null,
        worktree: wf.dirHash ?? null,
        workflow: wf,
        scope,
      });
    }
  }
  return out;
}

/**
 * Cross-workflow scope column definitions. Status groups become columns,
 * mirroring the shape-up notion of "where is this scope on the hill chart".
 *
 * Status is read from `scope.status` (the canonical field in stelow.json).
 * Unknown statuses fall into 'other' to keep the column count stable.
 */
export const SCOPE_COLUMNS = [
  { id: 'pending', label: 'Pending' },
  { id: 'in-progress', label: 'In Progress' },
  { id: 'escalated', label: 'Escalated' },
  { id: 'failed', label: 'Failed' },
  { id: 'completed', label: 'Completed' },
];

/**
 * Group a flat scope list into columns by status. Pure, deterministic.
 */
export function groupScopesByStatus(flat) {
  const buckets = Object.fromEntries(SCOPE_COLUMNS.map(c => [c.id, []]));
  buckets.other = [];
  for (const entry of flat) {
    const status = entry.scope?.status ?? 'other';
    if (buckets[status]) buckets[status].push(entry);
    else buckets.other.push(entry);
  }
  return buckets;
}

/**
 * v0.43.0: list all known projects for the cross-project picker UI.
 * Calls `muxy.projects.list()` and normalizes the shape. Returns an
 * empty array on any error (sandbox or permission missing).
 */
export async function loadProjectList() {
  try {
    const projects = await muxy.projects.list();
    return (Array.isArray(projects) ? projects : []).map((p) => ({
      id: p.id ?? p.path ?? null,
      name: p.name ?? p.path?.split('/').filter(Boolean).pop() ?? null,
      path: p.path ?? null,
      isActive: Boolean(p.isActive),
    }));
  } catch {
    return [];
  }
}

export function normalizeTrackingDataForProject(tracking, projectPath) {
  if (!tracking) return null;
  if (!projectPath) return tracking;
  return {
    ...tracking,
    workflows: (tracking.workflows || []).map(wf => ({
      ...wf,
      staleCwd: Boolean(wf.cwd && !isWorkflowCwdCompatible(wf.cwd, projectPath)),
      staleAt: wf.status === 'in-progress' && wf.updated
        ? (Date.now() - new Date(wf.updated).getTime() > 24 * 60 * 60 * 1000)
        : false,
    })),
  };
}

function isWorkflowCwdCompatible(workflowCwd, projectPath) {
  const normalizedWorkflowCwd = normalizePath(workflowCwd);
  const normalizedProjectPath = normalizePath(projectPath);
  return normalizedWorkflowCwd === normalizedProjectPath
    || normalizedWorkflowCwd.startsWith(`${normalizedProjectPath}/`)
    || normalizedProjectPath.startsWith(`${normalizedWorkflowCwd}/`);
}

/**
 * Group workflows into macro-stage buckets.
 * Returns [{ stage, workflows: [...] }, ...]
 */
export function groupWorkflowsByMacroStage(workflows) {
  const buckets = MACRO_STAGES.map(s => ({ ...s, workflows: [] }));
  const doneBucket = {
    id: 'done',
    name: 'Done',
    phaseRange: [0, PHASE_NAMES.length - 1],
    workflows: [],
  };

  for (const wf of workflows) {
    // Skip archived/aborted/stopped workflows and workflows whose cwd points
    // outside the active project. Stale cwd data usually means a copied or
    // orphaned tracking file, and showing it as active creates false progress.
    if (isHiddenWorkflowStatus(wf.status) || wf.staleCwd) continue;

    if (wf.status === 'completed') {
      doneBucket.workflows.push(wf);
      continue;
    }

    const phaseIdx = wf.currentPhase ?? 0;
    const bucket = buckets.find(
      b => phaseIdx >= b.phaseRange[0] && phaseIdx <= b.phaseRange[1]
    );
    if (bucket) {
      bucket.workflows.push(wf);
    } else {
      // Unknown phase → put in Shape bucket
      buckets[0].workflows.push(wf);
    }
  }

  return [...buckets, doneBucket];
}

export function getMacroStage(workflow) {
  if (workflow.status === 'completed') {
    return {
      id: 'done',
      name: 'Done',
      phaseRange: [0, PHASE_NAMES.length - 1],
    };
  }
  const phaseIdx = workflow.currentPhase ?? 0;
  return MACRO_STAGES.find(
    m => phaseIdx >= m.phaseRange[0] && phaseIdx <= m.phaseRange[1]
  ) ?? null;
}

/**
 * Get the precise phase name for a workflow.
 */
export function getPhaseName(workflow) {
  const idx = workflow.currentPhase ?? 0;
  return PHASE_NAMES[idx] || `Phase ${idx}`;
}

/**
 * Get overall progress of a workflow (0-1).
 */
export function getWorkflowProgress(workflow) {
  if (workflow.status === 'completed') return 1;
  const total = PHASE_NAMES.length;
  const current = workflow.currentPhase ?? 0;
  return Math.min(current / (total - 1), 1);
}

/**
 * Get status badge info for a workflow.
 */
export function getStatusBadge(workflow) {
  if (workflow.staleCwd) return { label: 'Stale cwd', class: 'badge-archived' };
  switch (workflow.status) {
    case 'in-progress': return { label: 'Active', class: 'badge-in-progress' };
    case 'paused': return { label: 'Paused', class: 'badge-paused' };
    case 'completed': return { label: 'Done', class: 'badge-completed' };
    case 'archived': return { label: 'Archived', class: 'badge-archived' };
    default: return { label: workflow.status, class: 'badge-in-progress' };
  }
}

// ── Scope helpers ─────────────────────────────────────────────────────

const SCOPE_STATUS_INFO = {
  pending: { label: 'Pending', tone: 'muted' },
  'in-progress': { label: 'Active', tone: 'primary' },
  completed: { label: 'Done', tone: 'success' },
  escalated: { label: 'Escalated', tone: 'danger' },
  failed: { label: 'Failed', tone: 'danger' },
};

export function getScopeStatusInfo(status) {
  return SCOPE_STATUS_INFO[status] ?? { label: status || 'Pending', tone: 'muted' };
}

/**
 * Get scope progress summary for a workflow.
 * Returns null if no scopes exist.
 *
 * The `declaredFilesCount` field surfaces the sum of `target_files` arrays
 * across all scopes that declared them — a quick at-a-glance signal that
 * the workflow is using the file-overlap prevention layer. When 0, no
 * scope opted in; treat the workflow as freeform.
 *
 * v0.43.0+: also computes `taskDone`/`taskTotal` across all scopes
 * for the pipeline card task summary. Separate from scope progress
 * because tasks are a sub-item checklist (Shape Up hill chart inside
 * each scope).
 */
export function getScopeProgress(workflow) {
  const scopes = workflow.scopes;
  if (!scopes || scopes.length === 0) return null;
  const total = scopes.length;
  const completed = scopes.filter(s => s.status === 'completed').length;
  const inProgress = scopes.filter(s => s.status === 'in-progress').length;
  const failed = scopes.filter(s => s.status === 'escalated' || s.status === 'failed').length;
  const pending = Math.max(total - completed - inProgress - failed, 0);
  const declaredFilesCount = scopes.reduce(
    (sum, s) => sum + (Array.isArray(s.target_files) ? s.target_files.length : 0),
    0
  );
  // Task aggregation: sum done/total across all scopes that have tasks[]
  const taskDone = scopes.reduce((sum, s) => {
    if (!Array.isArray(s.tasks)) return sum;
    return sum + s.tasks.filter(t => t.status === 'done').length;
  }, 0);
  const taskTotal = scopes.reduce((sum, s) => {
    if (!Array.isArray(s.tasks)) return sum;
    return sum + s.tasks.length;
  }, 0);
  // Count scopes with discovered tasks for badge
  const withDiscovered = scopes.filter(s => {
    if (!Array.isArray(s.tasks)) return false;
    return s.tasks.some(t => t.source === 'discovered');
  }).length;
  return { total, completed, inProgress, pending, failed, declaredFilesCount, taskDone, taskTotal, withDiscovered };
}

/**
 * Get a concise task summary text for display in pipeline cards.
 * Returns empty string when no tasks exist.
 *
 * Example: "tasks 12/18" or "tasks 12/18 [+2 discovered]"
 */
export function getTaskSummaryText(workflow) {
  const progress = getScopeProgress(workflow);
  if (!progress) return '';
  if (progress.taskTotal === 0) return '';
  const parts = [`tasks ${progress.taskDone}/${progress.taskTotal}`];
  if (progress.withDiscovered > 0) {
    // Count total discovered tasks across scopes
    let discoveredCount = 0;
    const scopes = workflow.scopes;
    if (Array.isArray(scopes)) {
      for (const s of scopes) {
        if (!Array.isArray(s.tasks)) continue;
        discoveredCount += s.tasks.filter(t => t.source === 'discovered').length;
      }
    }
    parts.push(`+${discoveredCount} discovered`);
  }
  return parts.join(' · ');
}

export function getScopeSummaryText(workflow) {
  const progress = getScopeProgress(workflow);
  if (!progress) return '';
  const parts = [
    `${progress.completed} done`,
    `${progress.inProgress} active`,
    `${progress.pending} pending`,
  ];
  if (progress.failed > 0) parts.push(`${progress.failed} failed`);
  // Append task summary when tasks exist
  const taskText = getTaskSummaryText(workflow);
  if (taskText) parts.push(taskText);
  // Surface file-overlap guard usage: when scopes declared target_files
  // the workflow is operating under the prevention protocol (file-locking.md).
  if (progress.declaredFilesCount > 0) {
    parts.push(`${progress.declaredFilesCount} declared paths`);
  }
  return parts.join(', ');
}

/**
 * Get scope badge info for display on kanban card.
 * Returns null if no scopes exist.
 */
/**
 * Intent badge configuration.
 * Maps intent → { icon, label, cssClass }.
 * Returns null for missing or unknown intent (no badge shown).
 */
const INTENT_BADGE = {
  'new-product': { icon: '\uD83C\uDD95', label: 'New', cssClass: 'badge-intent' },
  'feature':     { icon: '\u2728',      label: 'Feature', cssClass: 'badge-intent' },
  'bugfix':      { icon: '\uD83D\uDC1B', label: 'Bugfix', cssClass: 'badge-intent-bugfix' },
  'refactor':    { icon: '\uD83D\uDD27', label: 'Refactor', cssClass: 'badge-intent' },
  'investigate': { icon: '\uD83D\uDD0D', label: 'Research', cssClass: 'badge-intent' },
};

/**
 * Get intent badge info for a workflow.
 * Returns { icon, label, class } or null if no intent set or unknown.
 */
export function getIntentBadge(workflow) {
  if (!workflow || !workflow.intent) return null;
  const badge = INTENT_BADGE[workflow.intent];
  if (!badge) return null;
  return { icon: badge.icon, label: badge.label, class: badge.cssClass };
}

/**
 * Get scope badge info for display on kanban card.
 * Returns null if no scopes exist.
 */
export function getScopeBadge(workflow) {
  const progress = getScopeProgress(workflow);
  if (!progress) return null;
  const { total, completed, failed } = progress;
  if (total === 0) return null;
  let cls = 'badge-scope';
  if (completed === total) cls = 'badge-scope-done';
  else if (failed > 0) cls = 'badge-scope-failed';
  return { label: `${completed}/${total}`, class: cls };
}

/**
 * Return the active workflow for a project. Used by Muxy to avoid showing
 * workflow-scoped actions as if they applied to the clicked card when they
 * actually advance/complete the active workflow.
 */
/**
 * Find the active workflow in the panel.
 *
 * The "active workflow" drives `/sw-next`, `/sw-abort`, `/sw-complete`,
 * `/sw-archive` actions — these are unscoped commands that operate on the
 * single in-progress workflow in the current worktree. Returning a workflow
 * from a *different* worktree would cause the panel to act on it, leading
 * to the user-reported bug: "stelow says there's an active workflow but it's
 * from another directory". Filter to the current projectPath so the panel
 * never picks a foreign-worktree workflow.
 */
export function getActiveWorkflow(workflows, projectPath) {
  if (!projectPath) return null;
  return (workflows || []).find(wf => wf.status === 'in-progress'
      && !wf.staleCwd
      && isWorkflowFromProject(wf, projectPath)
  ) ?? null;
}

/**
 * Same path-prefix check used by `isWorkflowCwdCompatible`, but applied
 * to a workflow vs the current projectPath. Worktrees without a cwd
 * field (legacy workflows created before cwd tracking was added) are
 * accepted as compatible with any projectPath — mirrors the same
 * convention used in `isWorkflowFromProject` in the stelow extension
 * (`extensions/stelow/state.ts`).
 */
function isWorkflowFromProject(workflow, projectPath) {
  if (!projectPath) return false;
  const workflowCwd = workflow.cwd?.trim();
  if (!workflowCwd) return true;  // legacy fallback
  return isWorkflowCwdCompatible(workflowCwd, projectPath);
}

function quoteWorkflowName(name) {
  return `"${String(name ?? '').replace(/"/g, '\\"')}"`;
}

export function getWorkflowCommand(command, selectedWorkflow, activeWorkflow) {
  if (command === '/sw-abort') {
    return selectedWorkflow ? `/sw-abort ${quoteWorkflowName(selectedWorkflow.name)}` : '/sw-abort';
  }

  if (command === '/sw-archive') {
    return selectedWorkflow ? `/sw-archive name=${quoteWorkflowName(selectedWorkflow.name)}` : '/sw-archive';
  }

  if (selectedWorkflow && activeWorkflow?.name !== selectedWorkflow.name) {
    return null;
  }

  return command;
}

export function isWorkflowCommandEnabled(command, selectedWorkflow) {
  if (!selectedWorkflow) return true;
  if (selectedWorkflow.staleCwd) return false;
  if (selectedWorkflow?.status === 'completed' && command !== '/sw-archive') return false;
  if (command === '/sw-abort') {
    return selectedWorkflow.status === 'in-progress' || selectedWorkflow.status === 'paused';
  }
  if (command === '/sw-archive') {
    return selectedWorkflow.status !== 'archived';
  }
  return true;
}

export function getWorkflowCommandLabel(command, selectedWorkflow, activeWorkflow) {
  if (command === '/sw-next' && selectedWorkflow && activeWorkflow?.name !== selectedWorkflow.name) return 'Next active';
  if (command === '/sw-complete' && selectedWorkflow?.status === 'completed') return 'Done';
  if (command === '/sw-next' && selectedWorkflow?.status === 'completed') return 'Done';
  if (command === '/sw-abort' && selectedWorkflow?.status === 'completed') return 'Done';
  if (command === '/sw-abort' && selectedWorkflow?.staleCwd) return 'Stale cwd';
  if (command === '/sw-abort' && selectedWorkflow) return 'Abort selected';
  if (command === '/sw-archive' && selectedWorkflow) return 'Archive selected';
  return {
    '/sw-next': 'Next',
    '/sw-abort': 'Abort',
    '/sw-complete': 'Complete',
    '/sw-archive': 'Archive',
  }[command] ?? command;
}

export function getWorkflowCommandTitle(command, selectedWorkflow, activeWorkflow) {
  if (command === '/sw-next' && selectedWorkflow && activeWorkflow?.name !== selectedWorkflow.name) {
    return 'Only the active workflow can advance. Click the active workflow or run /sw-next in its project.';
  }
  if (command === '/sw-complete' && selectedWorkflow?.status === 'completed') {
    return 'Completed workflows belong in Done. Archive to hide/remove from the board.';
  }
  if (command === '/sw-next' && selectedWorkflow?.status === 'completed') {
    return 'Completed workflows belong in Done. Use /sw-unarchive if this was archived by mistake.';
  }
  if (command === '/sw-abort' && selectedWorkflow?.status === 'completed') {
    return 'Completed workflows do not need abort. Archive if you want to hide them.';
  }
  if (command === '/sw-complete' && selectedWorkflow && activeWorkflow?.name !== selectedWorkflow.name) {
    return 'Only the active workflow can be completed. Click the active workflow or run /sw-complete in its project.';
  }
  if (command === '/sw-abort' && selectedWorkflow?.staleCwd) {
    return 'Workflow cwd points outside the active project. Run a sync/repair before executing commands.';
  }
  if (command === '/sw-abort' && selectedWorkflow) {
    return `Execute /sw-abort for "${selectedWorkflow.name}" in the selected Pi pane.`;
  }
  if (command === '/sw-archive' && selectedWorkflow) {
    return `Execute /sw-archive for "${selectedWorkflow.name}" in the selected Pi pane.`;
  }
  return {
    '/sw-next': 'Execute /sw-next for the active workflow in the selected Pi pane.',
    '/sw-abort': 'Execute /sw-abort for the active workflow in the selected Pi pane.',
    '/sw-complete': 'Execute /sw-complete for the active workflow in the selected Pi pane.',
    '/sw-archive': 'Execute /sw-archive for the active workflow in the selected Pi pane.',
  }[command] ?? '';
}

// ── Artifact scanning ────────────────────────────────────────────────

const ARTIFACT_DIRS = ['specs', 'interfaces', 'plans', 'critiques', 'approvals'];
const ARTIFACT_DIR_ICONS = {
  specs: 'fileText',
  interfaces: 'columnShape',
  plans: 'fileText',
  critiques: 'alertCircle',
  approvals: 'circleCheck',
};
const ARTIFACT_DIR_LABELS = {
  specs: 'Specs',
  interfaces: 'Interfaces',
  plans: 'Plans',
  critiques: 'Critiques',
  approvals: 'Approvals',
};

export { ARTIFACT_DIRS, ARTIFACT_DIR_ICONS, ARTIFACT_DIR_LABELS };

/**
 * Scan session directories and build a map of workflow name → artifacts.
 * Returns Map<wfName, { artifacts: { specs: [], ... }, path: string }>
 */
export async function scanArtifactDirs() {
  const result = new Map();
  try {
    const dateDirs = await muxy.files.list('.stelow/');
    const dateDirPromises = dateDirs
      .filter(d => /^\d{4}-\d{2}-\d{2}$/.test(d))
      .map(async dateDir => {
        try {
          const sessionDirs = await muxy.files.list(`.stelow/${dateDir}/`);
          const sessionPromises = sessionDirs.map(async sessionDir => {
            try {
              const idxRes = await muxy.files.read(
                `.stelow/${dateDir}/${sessionDir}/index.json`
              );
              if (!idxRes?.content) return;
              const data = JSON.parse(idxRes.content);
              if (!data.name) return;
              const base = `.stelow/${dateDir}/${sessionDir}`;
              const artifacts = {};
              for (const dir of ARTIFACT_DIRS) {
                try {
                  const files = await muxy.files.list(`${base}/${dir}/`);
                  artifacts[dir] = files.filter(f => f.endsWith('.md'));
                } catch {
                  artifacts[dir] = [];
                }
              }
              // Only store if this name hasn't been seen, or this is newer
              if (!result.has(data.name)) {
                result.set(data.name, { artifacts, path: base, date: dateDir });
              }
            } catch { /* skip corrupt session */ }
          });
          await Promise.all(sessionPromises);
        } catch { /* skip unreadable date dir */ }
      });
    await Promise.all(dateDirPromises);
  } catch { /* no .stelow dir */ }
  return result;
}

/**
 * Get total artifact count for display on a card badge.
 */
export function getArtifactCount(artifactData) {
  if (!artifactData) return 0;
  return Object.values(artifactData.artifacts).reduce(
    (sum, files) => sum + files.length, 0
  );
}

// ── Phase ↔ artifact mapping ──────────────────────────────────────────

/** Rough mapping: which artifact dir a phase produces */
const PHASE_TO_ARTIFACT_DIR = {
  Shape: 'specs',
  Scope: 'specs',
  Critique: 'critiques',
  Gate: 'approvals',
  'Int.Gate': 'approvals',
  Interface: 'interfaces',
  Planning: 'plans',
  Execution: 'specs',
};
export { PHASE_TO_ARTIFACT_DIR };

/**
 * Get artifacts relevant to a specific phase.
 */
export function getArtifactsForPhase(artifactData, phaseName) {
  if (!artifactData) return [];
  const dir = PHASE_TO_ARTIFACT_DIR[phaseName];
  if (!dir) return [];
  return artifactData.artifacts[dir] || [];
}

/**
 * Get the next pending or upcoming phase after current.
 * Returns { name, index, status } or null if workflow is complete.
 */
export function getNextPhaseInfo(workflow) {
  const phases = workflow.phases || [];
  const current = workflow.currentPhase ?? 0;
  // Look for first non-completed phase at or after current
  for (let i = current; i < phases.length; i++) {
    if (phases[i]?.status !== 'completed') {
      return { name: phases[i]?.name || PHASE_NAMES[i], index: i, status: phases[i]?.status || 'pending' };
    }
  }
  return null;
}

/**
 * Get the active/in-progress phase name.
 * Returns { name, index } or null.
 */
export function getCurrentPhaseInfo(workflow) {
  const phases = workflow.phases || [];
  const current = workflow.currentPhase ?? 0;
  const phase = phases[current];
  return phase
    ? { name: phase.name, index: current, status: phase.status }
    : { name: PHASE_NAMES[current] || 'Unknown', index: current, status: 'in-progress' };
}

/**
 * Read the content of an artifact file.
 * artifactData — from artifactMap.get(wfName)
 * dir — 'specs' | 'interfaces' | 'plans' | 'critiques' | 'approvals'
 * filename — e.g. 'spec-auth-passkeys.md'
 */
export async function readArtifactFile(artifactData, dir, filename) {
  if (!artifactData) return null;
  try {
    const fullPath = `${artifactData.path}/${dir}/${filename}`;
    const res = await muxy.files.read(fullPath);
    return res?.content || null;
  } catch {
    return null;
  }
}

/**
 * Workflow commands are Pi TUI input. Execute them by typing into a Muxy
 * terminal pane and pressing Enter.
 */
const WORKFLOW_COMMAND_LABELS = {
  '/sw-next': 'Run /sw-next?',
  '/sw-abort': 'Run /sw-abort?',
  '/sw-complete': 'Run /sw-complete?',
  '/sw-archive': 'Run /sw-archive?',
};

const WORKFLOW_COMMAND_MESSAGES = {
  '/sw-next': 'This will send `/sw-next` to the selected Pi terminal pane and press Enter. This advances the active workflow.',
  '/sw-abort': 'This will send `/sw-abort` to the selected Pi terminal pane and press Enter. With a workflow name, it stops that workflow; otherwise it stops the active workflow.',
  '/sw-complete': 'This will send `/sw-complete` to the selected Pi terminal pane and press Enter. This marks the active workflow complete.',
  '/sw-archive': 'This will send `/sw-archive` to the selected Pi terminal pane and press Enter. With a workflow name, it archives that workflow; otherwise it archives the active workflow.',
};

export async function runWorkflowCommand(command) {
  const title = WORKFLOW_COMMAND_LABELS[command] ?? `Run ${command}?`;
  const baseMessage = WORKFLOW_COMMAND_MESSAGES[command]
    ?? `This will send \`${command}\` to a Pi terminal pane and press Enter.`;

  try {
    const panes = await muxy.panes.list();
    const resolution = await resolvePreferredPane(panes);
    const message = buildConfirmMessage(baseMessage, resolution);

    const choice = await muxy.dialog.confirm({
      title,
      message,
      buttons: ['Run', 'Cancel'],
      default: 'Cancel',
      cancel: 'Cancel',
      style: 'warning',
    });

    if (choice !== 'Run') {
      return { ok: false, reason: 'cancelled', copied: false };
    }

    const pane = resolution.pane ?? await selectTerminalPane(panes);
    if (!pane) {
      return { ok: false, reason: 'No terminal panes open', copied: false };
    }

    await muxy.panes.send(pane.id, command);
    await muxy.panes.sendKeys(pane.id, 'Enter');
    return { ok: true, paneTitle: pane.title || pane.id, copied: false };
  } catch (error) {
    const copied = await copyToClipboard(command).catch(() => false);
    return {
      ok: false,
      reason: error?.message ?? String(error),
      copied,
    };
  }
}

async function resolvePreferredPane(panes) {
  if (!panes || panes.length === 0) {
    return { pane: null, workspacePath: null, workspacePanes: [], focusedOutsideWorkspace: false };
  }

  const workspacePath = await getActiveWorkspacePath().catch(() => null);
  const workspacePanes = workspacePath
    ? panes.filter(pane => pane.workingDirectory && pathIsInside(pane.workingDirectory, workspacePath))
    : panes;
  const focused = panes.find(isFocusedPane);
  const focusedInWorkspace = workspacePanes.find(p => focused && p.id === focused.id);
  const projectName = workspacePath ? pathBasename(workspacePath) : null;
  const focusedMatchesProject = focused && projectName && paneMatchesProjectName(focused, projectName);
  const candidates = workspacePanes.length > 0 ? workspacePanes : panes;

  if (workspacePath && workspacePanes.length === 0 && focusedMatchesProject) {
    return { pane: focused, workspacePath, workspacePanes, focusedOutsideWorkspace: false };
  }

  if (workspacePath && workspacePanes.length === 0) {
    return { pane: null, workspacePath, workspacePanes, focusedOutsideWorkspace: true };
  }

  if (workspacePanes.length === 1) {
    return { pane: workspacePanes[0], workspacePath, workspacePanes, focusedOutsideWorkspace: false };
  }

  if (focusedInWorkspace) {
    return { pane: focusedInWorkspace, workspacePath, workspacePanes, focusedOutsideWorkspace: false };
  }

  const titleMatch = candidates.find(p => /(^|\s)pi(\s|$)/i.test(p.title ?? ''));
  if (titleMatch) {
    return { pane: titleMatch, workspacePath, workspacePanes, focusedOutsideWorkspace: Boolean(focused && !focusedInWorkspace) };
  }

  const cwdMatch = candidates.find(p => /(^|\s)pi(\s|$)/i.test(p.workingDirectory ?? ''));
  if (cwdMatch) {
    return { pane: cwdMatch, workspacePath, workspacePanes, focusedOutsideWorkspace: Boolean(focused && !focusedInWorkspace) };
  }

  return { pane: null, workspacePath, workspacePanes, focusedOutsideWorkspace: Boolean(focused && !focusedInWorkspace) };
}

function buildConfirmMessage(baseMessage, resolution) {
  if (resolution.pane) {
    return `${baseMessage} Target: ${formatPaneForDialog(resolution.pane)}. Active workspace: ${resolution.workspacePath ?? 'unknown'}.`;
  }

  if (resolution.focusedOutsideWorkspace) {
    return `${baseMessage} Focused pane is outside the active workspace/project. You will pick a pane from the active workspace/project.`;
  }

  if (resolution.workspacePanes.length > 1) {
    return `${baseMessage} Multiple terminal panes are open in the active workspace/project. You will pick the target pane.`;
  }

  return `${baseMessage} If multiple panes are open, you will pick the target pane.`;
}

function formatPaneForDialog(pane) {
  const title = pane.title || 'Untitled pane';
  const cwd = pane.workingDirectory ? ` (${pane.workingDirectory})` : '';
  return `${title}${cwd}`;
}

async function selectTerminalPane(panes) {
  if (!panes || panes.length === 0) {
    return null;
  }

  if (panes.length === 1) {
    return panes[0];
  }

  const workspacePath = await getActiveWorkspacePath().catch(() => null);
  const workspacePanes = workspacePath
    ? panes.filter(pane => pane.workingDirectory && pathIsInside(pane.workingDirectory, workspacePath))
    : panes;
  if (workspacePath && workspacePanes.length === 0) {
    const focused = panes.find(isFocusedPane);
    const projectName = pathBasename(workspacePath);
    if (focused && paneMatchesProjectName(focused, projectName)) {
      return focused;
    }
  }
  const candidates = workspacePanes.length > 0 ? workspacePanes : panes;
  const focused = panes.find(isFocusedPane);
  const focusedInCandidates = candidates.find(p => focused && p.id === focused.id);

  if (focusedInCandidates) {
    return focusedInCandidates;
  }

  const items = paneItems(candidates);
  const choice = await muxy.modal.open({
    placeholder: 'Select Pi pane',
    emptyLabel: 'No terminal panes',
    noMatchLabel: 'No matching panes',
    items: focusedInCandidates
      ? [paneToItem(focusedInCandidates), ...items.filter(item => item.id !== focusedInCandidates.id)]
      : items,
  });

  if (!choice) return null;
  return panes.find(p => p.id === choice.id) ?? null;
}

export async function getActiveWorkspacePath() {
  const projects = await muxy.projects.list();
  const activeProject = projects.find(project => project.isActive);
  if (!activeProject) return null;

  const worktrees = await muxy.worktrees.list(activeProject.id).catch(() => []);
  const activeWorktree = worktrees.find(worktree => worktree.isActive);
  return activeWorktree?.path ?? activeProject.path;
}

function paneMatchesProjectName(pane, projectName) {
  if (!projectName) return false;
  const haystack = `${pane.title ?? ''} ${pane.workingDirectory ?? ''}`.toLowerCase();
  return haystack.includes(projectName.toLowerCase());
}

function pathBasename(path) {
  return normalizePath(path).split('/').filter(Boolean).pop() ?? '';
}

function isFocusedPane(pane) {
  return Boolean(pane?.isFocused || pane?.focused);
}

function pathIsInside(candidatePath, parentPath) {
  const normalizedCandidate = normalizePath(candidatePath).toLowerCase();
  const normalizedParent = normalizePath(parentPath).toLowerCase();
  return normalizedCandidate === normalizedParent
    || normalizedCandidate.startsWith(`${normalizedParent}/`);
}

function normalizePath(path) {
  return path.replace(/\/+/g, '/').replace(/\/$/, '');
}

/**
 * MIRROR of `findProjectWorkflowRoot` in extensions/stelow/workflow-root.ts.
 *
 * The extension (Node) and the muxy panel (browser/electron) cannot share
 * TypeScript imports — vite builds the panel separately and the panel uses
 * `muxy.exec` for shell access instead of `child_process`. So we keep a
 * parallel implementation here, with the same algorithm:
 *
 *   1. cwd has its own tracking → it's the project root.
 *   2. Walk up to git toplevel of cwd — if a parent has tracking, use it.
 *   3. cwd as fallback.
 *
 * Bug fix (v0.36.2): the previous logic climbed up to any parent that had
 * tracking, falsely attributing a sibling project's workflow state to the
 * current cwd. The git-toplevel check prevents this.
 *
 * If you change one of these functions, change the other and add a test.
 */
export async function findProjectWorkflowRoot(cwd) {
  if (!cwd) return cwd;
  // Best-effort: this mirror is used only for display decisions in the
  // panel. The extension is the source of truth for workflow state; the
  // panel shows what the extension has already written. If git/shell is
  // unavailable, we fall through to cwd which is the conservative choice
  // (no false attribution to parent projects).
  if (hasTracking(cwd)) return cwd;
  // (We don't shell out to git here — the panel is display-only. If the
  // extension's tracking has cwd on each workflow, the panel can filter
  // directly via getActiveWorkflow(this.workflows, this.projectPath)
  // — see app.js. This resolver exists for future use; today it always
  // returns cwd because hasTracking() returns false in the panel context.)
  return cwd;
}

function hasTracking(dir) {
  // The panel runs in the muxy webview where node fs APIs are not directly
  // available. Reading tracking files requires async muxy.files.read which
  // complicates a sync resolver. The panel already filters workflows by
  // projectPath in getActiveWorkflow (which is the actual fix), so this
  // resolver is a placeholder for the extension's logic.
  return false;
}

function paneItems(panes) {
  return panes.map(paneToItem);
}

function paneToItem(pane) {
  return {
    id: pane.id,
    title: pane.title || 'Untitled pane',
    subtitle: [
      pane.workingDirectory || 'No working directory',
      isFocusedPane(pane) ? 'focused' : null,
    ].filter(Boolean).join(' · '),
  };
}

/**
 * Load workflows from global tracking that belong to other worktrees.
 * This gives a multi-worktree view of all workflows in the project.
 * Muxy may not support absolute paths; if it fails, returns empty.
 */
export async function loadExtraWorkflows() {
  try {
    const home = typeof process !== 'undefined' && process.env?.HOME ? process.env.HOME : '';
    if (!home) return [];
    const globalPath = `${home}/.stelow-global.json`;
    const res = await muxy.files.read(globalPath);
    if (!res || !res.content) return [];
    const global = JSON.parse(res.content);
    const projectPath = await getActiveWorkspacePath().catch(() => null);
    if (!projectPath) return [];

    // Scope to same git repository (not same project directory).
    // This avoids showing unrelated workflows from other repos
    // while still showing worktrees and sibling branches.
    const repoRoot = await getGitRoot(projectPath).catch(() => null);
    if (!repoRoot) return [];

    return (await Promise.all(global.workflows
      .filter(w => w.cwd
        && normalizePath(w.cwd).startsWith(`${normalizePath(repoRoot)}/`)
        && !isWorkflowCwdCompatible(w.cwd, projectPath)
      )
      .map(async w => {
        // Fetch real status from the project's local tracking file
        try {
          const localPath = `${normalizePath(w.cwd)}/stelow.json`;
          const localRes = await muxy.files.read(localPath);
          if (!localRes || !localRes.content) return null;
          const local = JSON.parse(localRes.content);
          const live = local.workflows?.find(lw => lw.name === w.name);
          if (!live || isHiddenWorkflowStatus(live.status)) return null;
          return {
            ...live,
            cwd: w.cwd,
            dirHash: w.dirHash,
            staleCwd: false,
            worktreeName: guessWorktreeName(w.cwd, projectPath),
            fromGlobal: true,
          };
        } catch {
          return null;
        }
      }))).filter(Boolean);
  } catch {
    return [];
  }
}

function guessWorktreeName(workflowCwd, projectPath) {
  const normalized = normalizePath(workflowCwd);
  const parts = normalized.split('/');
  const wtIdx = parts.findIndex(p => p === 'worktree-checkouts');
  if (wtIdx !== -1 && wtIdx + 2 < parts.length) return parts[wtIdx + 2];
  return parts[parts.length - 1] || pathBasename(workflowCwd);
}

/**
 * Find the git repository root for a given directory.
 * Walks up until it finds .git or HEAD marker.
 * Returns null if not determined.
 */
async function getGitRoot(startDir) {
  let dir = normalizePath(startDir);
  while (dir) {
    try {
      const entries = await muxy.files.list(dir);
      if (entries.some(e => e === '.git' || e === 'HEAD')) return dir;
    } catch {
      // Permission denied or not a directory
    }
    const parent = dir.split('/').slice(0, -1).join('/');
    if (!parent || parent === dir) break;
    dir = parent;
  }
  return null;
}

/**
 * Copy text to clipboard using muxy.exec + pbcopy.
 * Uses base64 to avoid shell quoting issues with special chars.
 */
export async function copyToClipboard(text) {
  try {
    const b64 = btoa(text);
    await muxy.exec({ shell: `echo ${b64} | base64 -d | pbcopy` });
    return true;
  } catch {
    return false;
  }
}

// ── Name & Display helpers ────────────────────────────────────────────

/**
 * Generate a safe kebab-case name from text.
 */
export function toSafeName(text) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, ' ')
    .trim()
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 40);
}

/**
 * Get a YYYY-MM-DD date stamp.
 */
export function getDateStamp(date) {
  return (date || new Date()).toISOString().slice(0, 10);
}

/**
 * Derive a representative display name from draft content.
 * Extracts the first meaningful sentence or phrase.
 */
export function summarizeDisplayName(draftContent) {
  if (!draftContent) return null;
  let clean = draftContent
    .replace(/```[\s\S]*?```/g, '')
    .replace(/=== FILE:.*?===/g, '')
    .replace(/### Initial Draft\n\n/, '')
    .trim();
  // First non-empty line — up to 120 chars, then ellipsis
  const firstLine = clean.split('\n')[0]?.trim();
  if (firstLine && firstLine.length > 3) {
    if (firstLine.length <= 120) return firstLine;
    // Return first ~117 chars + ellipsis
    let cut = firstLine.slice(0, 117);
    // Try to break at word boundary
    const lastSpace = cut.lastIndexOf(' ');
    if (lastSpace > 60) cut = cut.slice(0, lastSpace);
    return cut + '...';
  }
  // Fallback: first 120 chars of any text
  if (clean.length > 0) {
    if (clean.length <= 120) return clean;
    let cut = clean.slice(0, 117);
    const lastSpace = cut.lastIndexOf(' ');
    if (lastSpace > 60) cut = cut.slice(0, lastSpace);
    return cut + '...';
  }
  return null;
}

/**
 * Persist workflow metadata fields to both tracking file and index.json.
 * wf: workflow object (needs name for lookup, dirHash + created for index.json path)
 * updates: partial fields to merge (e.g. { displayName: '...' })
 */
export async function persistWorkflowMeta(wf, updates) {
  const res = await muxy.files.read('stelow.json');
  if (!res?.content) return false;
  const tracking = JSON.parse(res.content);
  const entry = tracking.workflows.find(w => w.name === wf.name);
  if (!entry) return false;
  Object.assign(entry, updates, { updated: new Date().toISOString() });
  await muxy.files.write('stelow.json', JSON.stringify(tracking, null, 2));

  // Also persist to index.json
  if (wf.dirHash && wf.created) {
    const ds = getDateStamp(new Date(wf.created));
    const idxPath = `.stelow/${ds}/${wf.dirHash}/index.json`;
    try {
      const idxRes = await muxy.files.read(idxPath);
      if (idxRes?.content) {
        const idx = JSON.parse(idxRes.content);
        Object.assign(idx, updates, { updated_at: new Date().toISOString() });
        await muxy.files.write(idxPath, JSON.stringify(idx, null, 2));
      }
    } catch { /* skip unreadable index */ }
  }

  return true;
}

/**
 * Rename a workflow: set a new display name and kebab-safe name.
 * oldName: current name for lookup in the tracking file
 * newDisplayName: new human-readable name
 * Returns the new safe name, or null on failure.
 */
export async function renameWorkflowInFiles(oldName, newDisplayName, wf) {
  const safeName = toSafeName(newDisplayName);
  if (!safeName || safeName.length < 2) return null;

  const res = await muxy.files.read('stelow.json');
  if (!res?.content) return null;
  const tracking = JSON.parse(res.content);
  const entry = tracking.workflows.find(w => w.name === oldName);
  if (!entry) return null;
  entry.name = safeName;
  entry.displayName = newDisplayName;
  entry.updated = new Date().toISOString();
  await muxy.files.write('stelow.json', JSON.stringify(tracking, null, 2));

  // Update index.json
  if (wf.dirHash && wf.created) {
    const ds = getDateStamp(new Date(wf.created));
    const idxPath = `.stelow/${ds}/${wf.dirHash}/index.json`;
    try {
      const idxRes = await muxy.files.read(idxPath);
      if (idxRes?.content) {
        const idx = JSON.parse(idxRes.content);
        idx.name = safeName;
        idx.displayName = newDisplayName;
        idx.updated_at = new Date().toISOString();
        await muxy.files.write(idxPath, JSON.stringify(idx, null, 2));
      }
    } catch { /* skip unreadable index */ }
  }

  return safeName;
}
