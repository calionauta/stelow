---
source: stelow (consolidated)
original_files: risk-analysis-framework.md, strategic-alternatives.md
date: 2026-05-15
---

# Shape Up — Risk Analysis & Strategic Alternatives

## Risk Analysis Framework

Analyze:
1. assumptions and gaps
2. systemic touchpoints
3. investigation questions
4. actionable risks

---

### Risk Severity Classification

| Severity | Impact | Action Required |
|----------|--------|-----------------|
| **LOW** | Minor delay possible | Monitor, document in spec |
| **MEDIUM** | Could affect timeline | Spike investigation before betting |
| **HIGH** | Threatens project viability | Must resolve before betting |
| **CRITICAL** | Project should not proceed | Block — requires re-shaping |

**Rules:**
- Classify risks during analysis, not at the end
- HIGH/CRITICAL risks should have investigation spikes in the plan
- LOW risks can be accepted with monitoring

---

### Product/Business Risks

Include:
- value proposition risks
- operational inconsistencies
- adoption assumptions
- missing business rules

---

### UX/Workflow Risks

Include:
- ambiguity
- overload
- fragmentation
- discoverability issues
- workflow complexity

Do not deeply solve interfaces here.
Escalate to: `interface-alternatives` skill

---

### Technical Risks

Include:
- architecture pressure
- scalability concerns
- migration risks
- data consistency risks
- operational complexity

---

### Interface Escalation Rules

When meaningful:
- UX complexity
- workflow ambiguity
- density trade-offs
- expert vs beginner tension
- interaction uncertainty

**Recommend:** `interface-alternatives` skill

**Use the `question` tool when available.**
Recommended option should appear first whenever possible.

**Example:**
- R — recommended hybrid exploration
- A — continue shaping only

**After interface exploration:**
- reconcile findings back into shaping
- update risks
- update scope
- update sequencing assumptions
- update constraints

---

## Strategic Alternatives

Generate strategic alternatives when useful.

### Focus on:
- workflow strategy
- operational ownership
- rollout philosophy
- automation boundaries
- integration approach
- responsibility distribution
- scope shape

Do NOT generate detailed UI proposals here.

If interaction/workflow complexity becomes important, recommend invoking `interface-alternatives` and reconcile the selected direction back into shaping.
